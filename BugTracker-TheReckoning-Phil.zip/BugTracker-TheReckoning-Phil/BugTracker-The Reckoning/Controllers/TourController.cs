﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BugTracker_The_Reckoning.Controllers
{
    public class TourController : Controller
    {
        // GET: Tour
        public ActionResult Index()
        {

            return View();
        }
    }
}